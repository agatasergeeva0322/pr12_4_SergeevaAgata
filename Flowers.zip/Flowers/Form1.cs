﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Contracts;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Diagnostics.Eventing.Reader;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Flowers
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            Flowers[] flowers = new Flowers[10];
            int i = listBox1.SelectedIndex;
            flowers[i] = new Flowers("", "", "", "", 0, 0, 0, 0);
            if (textBox1.Text == "") MessageBox.Show("Вы не ввели название!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (textBox2.Text == "") MessageBox.Show("Вы не ввели тип цветка!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (textBox3.Text == "") MessageBox.Show("Вы не ввели цвет!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (textBox4.Text == "") MessageBox.Show("Вы не ввели страну-производитель!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (textBox5.Text == "") MessageBox.Show("Вы не ввели цену", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (textBox6.Text == "") MessageBox.Show("Вы не ввели длину стебля!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (textBox7.Text == "") MessageBox.Show("Вы не ввели количество цветов в букете!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                flowers[i].name = Convert.ToString(textBox1.Text);
                flowers[i].type = Convert.ToString(textBox2.Text);
                flowers[i].color = Convert.ToString(textBox3.Text);
                flowers[i].country = Convert.ToString(textBox4.Text);
                flowers[i].price = Convert.ToDouble(textBox5.Text);
                if (Convert.ToDouble(textBox5.Text) > 0)
                {
                    flowers[i].stemLength = Convert.ToInt32(textBox6.Text);
                    if (Convert.ToDouble(textBox6.Text) > 0)
                    {
                        if (textBox7.Text != "" && Convert.ToInt32(textBox7.Text) > 0)
                        {
                            flowers[i].count = Convert.ToInt32(textBox7.Text);
                            flowers[i].form = comboBox1.SelectedIndex;
                            MessageBox.Show($"{flowers[i].TotalCost(flowers[i].price, flowers[i].count)} руб. за {flowers[i].count} цветов");             
                            listBox1.Items[i] = $"№ {i + 1}: " + Convert.ToString(flowers[i].FlowerInfo()) + ", " + flowers[i].Form(flowers[i].form);
                        }
                        else MessageBox.Show("Колиечество не может быть отрицательным!");
                    }
                    else MessageBox.Show("Длина не может быть отрицательной!");
                }
                else MessageBox.Show("Цена не может быть отрицательной!");

            }
        }
    }
    public class Flowers
    {
        public string name;
        public string type;
        public string color;
        public string country;
        public double price;
        public int stemLength;
        public int count;
        public int form;
        public Flowers(string name, string type, string color, string country, double  price, int stemLength, int count, int form)
        {
            this.name = name;
            this.type = type;
            this.color = color;
            this.country = country;
            this.price= price;
            this.count = count;
            this.form = form;

            
        }
        public double TotalCost(double price, int count)
        {
            return price * count;
        }
        public string Form(int form)
        {
            string form_flow = "";
            if (form == 2) form_flow = "Каркасная";
            else if (form == 1) form_flow = "Каскадная";
            else form_flow = "Круглая";
            return form_flow;
        }
        public string FlowerInfo()
        {
            return $"{type} {name}, {color},{stemLength} см, {country}, {price} руб. шт., {count} в букете";
        }
    }

}
